$safeprojectname$ = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceEvent-2.0")

function $safeprojectname$:OnInitialize()
		-- Called when the addon is loaded
end

function $safeprojectname$:OnEnable()
	-- Called when the addon is enabled
end

function $safeprojectname$:OnDisable()
		-- Called when the addon is disabled
end
