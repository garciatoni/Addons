$safeprojectname$ = LibStub("AceAddon-3.0"):NewAddon("$safeprojectname$", "AceConsole-3.0", "AceEvent-3.0" );

function $safeprojectname$:OnInitialize()
		-- Called when the addon is loaded

		-- Print a message to the chat frame
		self:Print("OnInitialize Event Fired: Hello")
end

function $safeprojectname$:OnEnable()
		-- Called when the addon is enabled

		-- Print a message to the chat frame
		self:Print("OnEnable Event Fired: Hello, again ;)")
end

function $safeprojectname$:OnDisable()
		-- Called when the addon is disabled
end
